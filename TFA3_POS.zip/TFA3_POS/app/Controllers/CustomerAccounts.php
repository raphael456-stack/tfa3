<?php
namespace App\Controllers;

use App\Models\CustomerModel;

class CustomerAccounts extends BaseController
{
    public function index()
    {
        $model = new CustomerModel();

        return view('customer_accounts', [
            'customers' => $model->findAll()
        ]);
    }

    public function new()
    {
        return view('customer_form', [
            'customer' => [],
            'isEdit' => false
        ]);
    }

    public function create()
    {
        $rules = [
            'full_name' => 'required|max_length[100]',
            'email' => 'required|valid_email|max_length[100]',
            'phone' => 'permit_empty|max_length[20]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $model = new CustomerModel();

        $model->insert([
            'full_name' => trim($this->request->getPost('full_name')),
            'email' => trim($this->request->getPost('email')),
            'phone' => trim($this->request->getPost('phone') ?? ''),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to(site_url('customer-accounts'))
            ->with('success', 'Customer created successfully.');
    }

    public function edit($id)
    {
        $model = new CustomerModel();
        $customer = $model->find($id);

        if (!$customer) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('customer_form', [
            'customer' => $customer,
            'isEdit' => true
        ]);
    }

    public function update($id)
    { 
        $model = new CustomerModel();
        $customer = $model->find($id);

        if (!$customer) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $rules = [
            'full_name' => 'required|max_length[100]',
            'email' => 'required|valid_email|max_length[100]',
            'phone' => 'permit_empty|max_length[20]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $model->update($id, [
            'full_name' => trim($this->request->getPost('full_name')),
            'email' => trim($this->request->getPost('email')),
            'phone' => trim($this->request->getPost('phone') ?? '')
        ]);

        return redirect()->to(site_url('customer-accounts'))
            ->with('success', 'Customer updated successfully.');
    }
}
