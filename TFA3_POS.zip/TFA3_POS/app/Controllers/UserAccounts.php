<?php
namespace App\Controllers;

use App\Models\UserModel;

class UserAccounts extends BaseController
{
    public function index()
    {
        $model = new UserModel();

        return view('user_accounts', [
            'users' => $model->findAll()
        ]);
    }

    public function new()
    {
        return view('user_form', [
            'user' => [],
            'isEdit' => false
        ]);
    }

    public function create()
    {
        $rules = [
            'username' => 'required|max_length[50]|is_unique[users.username]',
            'full_name' => 'required|max_length[100]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $model = new UserModel();

        $model->insert([
            'username' => trim($this->request->getPost('username')),
            'full_name' => trim($this->request->getPost('full_name')),
            'created_at' => date('Y-m-d H:i:s'),
            'avatar' => null
        ]);

        return redirect()->to(site_url('user-accounts'))
            ->with('success', 'User created successfully.');
    }

    public function edit($id)
    {
        $model = new UserModel();
        $user = $model->find($id);

        if (!$user) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('user_form', [
            'user' => $user,
            'isEdit' => true
        ]);
    }

    public function update($id)
    {
        $model = new UserModel();
        $user = $model->find($id);

        if (!$user) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $rules = [
            'username' => "required|max_length[50]|is_unique[users.username,id,{$id}]",
            'full_name' => 'required|max_length[100]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = [
            'username' => trim($this->request->getPost('username')),
            'full_name' => trim($this->request->getPost('full_name'))
        ];

        $file = $this->request->getFile('avatar');

        if ($file && $file->getError() !== UPLOAD_ERR_NO_FILE) {

            if (!$file->isValid()) {
                return redirect()->back()
                    ->withInput()
                    ->with('errors', [
                        'avatar' => 'The upload failed. Please try again.'
                    ]);
            }

            $allowedExtensions = ['jpg', 'jpeg', 'png'];
            $allowedMimes = ['image/jpeg', 'image/png'];

            $extension = strtolower($file->getExtension());
            $mime = $file->getMimeType();

            if (
                $file->getSize() > 2 * 1024 * 1024 ||
                !in_array($extension, $allowedExtensions, true) ||
                !in_array($mime, $allowedMimes, true) ||
                @getimagesize($file->getTempName()) === false
            ) {
                return redirect()->back()
                    ->withInput()
                    ->with('errors', [
                        'avatar' => 'Upload a valid JPG or PNG image no larger than 2 MB.'
                    ]);
            }

            $uploadPath = FCPATH . 'uploads/';

            if (!is_dir($uploadPath)) {
                if (!mkdir($uploadPath, 0755, true) && !is_dir($uploadPath)) {
                    return redirect()->back()
                        ->withInput()
                        ->with('errors', [
                            'avatar' => 'Unable to create the uploads folder.'
                        ]);
                }
            }

            $filename = $file->getRandomName();
            $target = $uploadPath . $filename;

            try {
                service('image')
                    ->withFile($file->getTempName())
                    ->fit(300, 300, 'center')
                    ->save($target);

            } catch (\Throwable $e) {

                dd($e->getMessage());
            }

            $data['avatar'] = $filename;
        }

        $model->update($id, $data);

        return redirect()->to(site_url('user-accounts'))
            ->with('success', 'User updated successfully.');
    }
}
