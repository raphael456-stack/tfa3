<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Account Form</title>
</head>
<body>

<h1><?= $isEdit ? 'Edit User' : 'New User' ?></h1>

<?php $errors = session()->getFlashdata('errors') ?? []; ?>

<?php if (!empty($errors)): ?>
    <ul style="color:red;">
        <?php foreach ($errors as $error): ?>
            <li><?= esc($error) ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="post"
    enctype="multipart/form-data"
    action="<?= $isEdit
        ? site_url('users/update/' . $user['id'])
        : site_url('users/create') ?>">

    <?= csrf_field() ?>

    <label>Username</label><br>
    <input type="text" name="username"
        value="<?= esc(old('username', $user['username'] ?? '')) ?>"
        required maxlength="50">
    <br><br>

    <label>Full Name</label><br>
    <input type="text" name="full_name"
        value="<?= esc(old('full_name', $user['full_name'] ?? '')) ?>"
        required maxlength="100">
    <br><br>

    <?php if ($isEdit && !empty($user['avatar'])): ?>
        <p>Current avatar:</p>
        <img
            src="<?= base_url('uploads/' . $user['avatar']) ?>"
            alt="Current user avatar"
            width="100" height="100">
        <br><br>
    <?php endif; ?>

    <?php if ($isEdit): ?>
        <label>Profile Picture (JPG or PNG, max 2 MB)</label><br>
        <input type="file" name="avatar" accept=".jpg,.jpeg,.png,image/jpeg,image/png">
        <p>Leave this empty to keep the current picture.</p>
        <br>
    <?php endif; ?>

    <button type="submit">
        <?= $isEdit ? 'Update User' : 'Create User' ?>
    </button>
</form>

<p><a href="<?= site_url('user-accounts') ?>">Back to User Accounts</a></p>

</body>
</html>
