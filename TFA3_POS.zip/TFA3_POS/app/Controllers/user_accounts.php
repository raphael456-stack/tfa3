<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Accounts</title>
</head>
<body>

<h1>User Accounts</h1>

<p>
    <a href="<?= site_url('users/new') ?>">
        Add New User
    </a>
</p>

<?php if ($message = session()->getFlashdata('success')): ?>
    <p style="color:green;"><?= esc($message) ?></p>
<?php endif; ?>

<p>
    <a href="<?= site_url('users/new') ?>">Add New User</a>
</p>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Avatar</th>
            <th>ID</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td>
                    <img
                        src="<?= !empty($user['avatar'])
                            ? base_url('uploads/' . $user['avatar'])
                            : base_url('images/placeholder.png') ?>"
                        alt="User avatar"
                        width="60"
                        height="60"
                        style="object-fit:cover; border-radius:50%;">
                </td>

                <td><?= esc($user['id']) ?></td>
                <td><?= esc($user['username']) ?></td>
                <td><?= esc($user['full_name']) ?></td>
                <td><?= esc($user['created_at']) ?></td>

                <td>
                    <a href="<?= site_url('users/edit/' . $user['id']) ?>">
                        Edit
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
 