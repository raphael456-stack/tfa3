<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Account Form</title>
</head>
<body>

<h1><?= $isEdit ? 'Edit Customer' : 'New Customer' ?></h1>

<?php $errors = session()->getFlashdata('errors') ?? []; ?>

<?php if (!empty($errors)): ?>
    <ul style="color:red;">
        <?php foreach ($errors as $error): ?>
            <li><?= esc($error) ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="post"
    action="<?= $isEdit
        ? site_url('customers/update/' . $customer['id'])
        : site_url('customers/create') ?>">

    <?= csrf_field() ?>

    <label>Full Name</label><br>
    <input type="text" name="full_name"
        value="<?= esc(old('full_name', $customer['full_name'] ?? '')) ?>"
        required maxlength="100">
    <br><br>

    <label>Email</label><br>
    <input type="email" name="email"
        value="<?= esc(old('email', $customer['email'] ?? '')) ?>"
        required maxlength="100">
    <br><br>

    <label>Phone</label><br>
    <input type="text" name="phone"
        value="<?= esc(old('phone', $customer['phone'] ?? '')) ?>"
        maxlength="20">
    <br><br>

    <button type="submit">
        <?= $isEdit ? 'Update Customer' : 'Create Customer' ?>
    </button>
</form>

<p><a href="<?= site_url('customer-accounts') ?>">Back to Customer Accounts</a></p>

</body>
</html>
